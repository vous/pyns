===========
pyns
===========

PyNS - a Python based Nation States API wrapper

Requirements:
* Beautiful Soup 4
* Mechanize